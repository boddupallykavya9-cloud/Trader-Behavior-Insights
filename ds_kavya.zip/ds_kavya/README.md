
# Junior Data Scientist – Trader Behavior Insights

## Project Overview
This project analyzes the relationship between trader performance and market sentiment using historical trader data and the Bitcoin Fear/Greed Index. The goal is to uncover patterns that inform smarter trading strategies within the Web3 ecosystem.

---

## Folder Structure
- notebook1.ipynb
- notebook1-2.ipynb
- csvfiles/
- outputs/
- dsreport.pdf
- README.md

---

## Data Sources
- Trader Data: trades with fields like Account, Coin, Execution Price, Size USD, Side, Timestamp IST, Start Position, Direction, Closed PnL, Fee, Trade ID, etc.
- Sentiment Data: timestamp, value, classification (Fear, Extreme Fear, Greed, Extreme Greed, Neutral), date.
- Data were cleaned (missing values handled, duplicates removed) and merged on date.

---

## How to Run
1. Open notebook1.ipynb (and/or notebook1-2.ipynb) in Colab or Jupyter.
2. Ensure data is available in csvfiles/ or upload when prompted.
3. Run cells in order to reproduce analyses and visualizations.
4. Outputs (plots) are saved in outputs/.
5. Generate the final report (dsreport.pdf) from the notebook or with an external tool.

---

## Main Analyses & Visualizations
- Time series of daily trade size and Closed PnL
- PnL by sentiment (Fear/Greed/Neutral)
- Correlation heatmaps (Size USD, PnL, Fee)
- Bar charts by sentiment class

---

## Findings & Recommendations
- Profitability tends to peak during Extreme Greed; Fear periods also show activity.
- Higher volume and fees accompany Fear/Greed sentiments.
- Recommend adaptive risk management and position sizing aligned with sentiment swings.

---

## Reproducibility & Requirements
- Python 3.x, pandas, numpy, matplotlib, seaborn
- Colab or Jupyter Notebook
